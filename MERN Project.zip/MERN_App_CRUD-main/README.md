# MERN_App_CRUD
A basic CRUD application built completely in MERN stack.
