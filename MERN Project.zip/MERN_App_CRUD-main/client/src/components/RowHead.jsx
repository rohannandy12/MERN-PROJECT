export const RowHead = () => {
  return (
    <div className="rowHeader">
      <div>
        <p>Sl. No.</p>
      </div>
      <div>
        <p>Name</p>
      </div>
      <div>
        <p>Phone No.</p>
      </div>
      <div>
        <p>Details</p>
      </div>
    </div>
  );
};
